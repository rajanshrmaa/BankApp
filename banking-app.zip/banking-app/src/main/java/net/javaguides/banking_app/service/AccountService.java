package net.javaguides.banking_app.service;


import net.javaguides.banking_app.entity.Account;
import net.javaguides.banking_app.repository.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AccountService {

   @Autowired
   private AccountRepository accountRepository;

   // Register Account
   public Account registerAccount(Account account) {
       // Generate account number based on phone number and current timestamp
       account.setAccountNumber(account.getAccountNumber());
       account.setBalance(account.getBalance());
       account.setPhoneNumber(account.getPhoneNumber());
       return accountRepository.save(account);
   }

   // Login (fetch account by phone number)
   

   // Deposit balance to the account
   public Account deposit(Long id, Double balance) {
       Account account = accountRepository.findById(id)
               .orElseThrow(() -> new RuntimeException("Account not found"));
       account.setBalance(account.getBalance() + balance);
       return accountRepository.save(account);
   }

   // Withdraw balance from the account
   public Account withdraw(Long id, double balance) {
       Account account = accountRepository.findById(id)
               .orElseThrow(() -> new RuntimeException("Account not found"));
       if (account.getBalance() < balance) {
           throw new RuntimeException("Insufficient balance");
       }
       account.setBalance(account.getBalance() - balance);
       return accountRepository.save(account);
   }

   // Update account details
   public Account updateAccount(Long id, Account updatedAccount) {
       Account account = accountRepository.findById(id)
               .orElseThrow(() -> new RuntimeException("Account not found"));
       account.setAccountHolderName(updatedAccount.getAccountHolderName());
       account.setPhoneNumber(updatedAccount.getPhoneNumber());
       return accountRepository.save(account);
   }
   
   public Optional<Account> getAccountDetails(Long id) {
	   Optional<Account> account = accountRepository.findById(id);
	   return account;
   }

public Account loginAccount(String phoneNumber) {
    return accountRepository.findByPhoneNumber(phoneNumber)
            .orElseThrow(() -> new RuntimeException("Account not found"));
}


}

