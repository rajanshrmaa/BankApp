package net.javaguides.banking_app.controller;
 
import net.javaguides.banking_app.entity.Account;
import net.javaguides.banking_app.service.AccountService;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
 
@RestController
@RequestMapping("/account")
public class AccountController {
 
    @Autowired
    private AccountService accountService;
 
    // Thymeleaf Register Account Page
    @GetMapping("/signup")
    public String showRegistrationForm(Model model) {
        model.addAttribute("account", new Account());
        return "register";
    }
 
    // Thymeleaf Login Account Page
    @GetMapping("/login")
    public String showLoginForm() {
        return "login";
    }
 
    // Thymeleaf Account Details Page
    /*@GetMapping("/details/{id}")
    public String getAccountDetails(@PathVariable("id") Long id, Model model) {
        Optional<Account> account = accountService.getAccountDetails(id);
        model.addAttribute("account", account);
        return "account-details";
    }*/
    
    @GetMapping("/details/{id}")
    public Optional<Account> getAccountDetails(@PathVariable("id") Long id) {
        return accountService.getAccountDetails(id);
    }
 
    // Postman: Register Account API (for Postman)
    @PostMapping("/register")
    public ResponseEntity<Account> registerAccount(@RequestBody Account account) {
        Account savedAccount = accountService.registerAccount(account);
        return ResponseEntity.ok(savedAccount);
    }
 
    // Postman: Login Account API (for Postman)
    @PostMapping("/login")
    public ResponseEntity<Account> loginAccount(@RequestBody Account account) {
        Account loggedInAccount = accountService.loginAccount(account.getPhoneNumber());
        return ResponseEntity.ok(loggedInAccount);
    }
 
    // Postman: Deposit Money API
    @PutMapping("/deposit/{id}")
    public ResponseEntity<Account> deposit(@PathVariable Long id, @RequestParam Double balance) {
        Account updatedAccount = accountService.deposit(id, balance);
        return ResponseEntity.ok(updatedAccount);
    }
 
    // Postman: Withdraw Money API
    @PutMapping("/withdraw/{id}")
    public ResponseEntity<Account> withdraw(@PathVariable Long id, @RequestParam double balance) {
        Account updatedAccount = accountService.withdraw(id, balance);
        return ResponseEntity.ok(updatedAccount);
    }
 
    // Thymeleaf Registration Form Submit (POST)
    @PostMapping("/register/user")
    public String registerAccount(@ModelAttribute("account") Account account, Model model) {
        accountService.registerAccount(account);
        model.addAttribute("message", "Account registered successfully!");
        return "register";
    }
 
    // Thymeleaf Deposit Form Submit (POST)
    @PostMapping("/deposit/{id}")
    public String depositMoney(@PathVariable("id") Long id, @RequestParam("balance") double balance, Model model) {
        Account updatedAccount = accountService.deposit(id, balance);
        model.addAttribute("account", updatedAccount);
        return "account-details";
    }
 
    // Thymeleaf Withdraw Form Submit (POST)
    @PostMapping("/withdraw/{id}")
    public String withdrawMoney(@PathVariable("id") Long id, @RequestParam("balance") double balance, Model model) {
        Account updatedAccount = accountService.withdraw(id, balance);
        model.addAttribute("account", updatedAccount);
        return "account-details";
    }
}
