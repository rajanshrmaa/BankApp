package net.javaguides.banking_app.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import net.javaguides.banking_app.entity.Account;

import java.util.Optional;
 
@Repository
public interface AccountRepository extends JpaRepository<Account, Long> {
 
    // Find account by phone number (for login)
    Optional<Account> findByPhoneNumber(String phoneNumber);
}
